.. _ensemble_examples:

Ensemble methods
----------------

Examples concerning the :mod:`sklearn.ensemble` module.
